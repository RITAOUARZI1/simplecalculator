#creat function for the addition operator
def add(x,y):
     return x+y
#creat a fuction for the substraction operation
def substract(x,y):
     return x-y
#creat a function for the multipliaction operator
def multiply(x,y):
     return x*y
#creat a fuction for the division operator
def divide(x,y):
    if y!=0:
           return x/y
    else:
           return " ERROR! because of the zero division"


#after we creat all the operator now
#so know we will creat the main method 
#that will drive the entire program (+ / * -)

#ask the user 
def calculator():
            print("select the operation that you want :")
            print("1.ADDITION")
            print("2.SUBSTRACTION")
            print("3.MULTIPLLY")
            print("4.DIVISION")


#get the user input 
choice = input("Enter choice (1/2/3/4):  ")

if choice in['1', '2','3','4']:
    #get the two number x and y from the user 
      num1 = float(input("Enter first number:  "))
      num2 = float(input("Enter second number:  "))

#perform the operation based on the user's choice

if choice =='1':
           print(f"{num1} + {num2} = {add(num1,num2)}")
elif choice =='2':
           print(f"{num1} - {num2} = {substract(num1,num2)}")
elif choice =='3':
          print(f"{num1} * {num2} = {multiply(num1,num2)}")
elif choice == '4':
        
          print(f"{num1} / {num2} = {divide(num1,num2)}")
 
else:
        print("not exist sorry!!")

#run the calculation 
calculator()
